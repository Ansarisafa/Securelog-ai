"""
generate_dataset.py - Makes the sample dataset (50,000 rows).

Run from the main project folder:
    python dataset/generate_dataset.py
It creates:  dataset/sample_logs.csv
"""
import sys
from pathlib import Path

# Let Python find the "modules" folder (one level up)
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from modules.sample_data import generate_sample_data  # noqa: E402

if __name__ == "__main__":
    df = generate_sample_data(n_rows=50_000, seed=42, days=7)
    df["time"] = df["time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    out_file = ROOT / "dataset" / "sample_logs.csv"
    df.to_csv(out_file, index=False)
    print(f"Done! {len(df)} rows saved to {out_file}")
    print(df.head())
