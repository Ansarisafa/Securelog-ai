# SecureLog AI – Viva Guide and Project Report

---
## PART 1 – How the AI works (simple explanation)

**Step 1 – Collect data.** Logs come from the Windows Security log or a CSV file.
Each row = one event (username, IP address, failed attempts, threat level, hour).

**Step 2 – Threat score (rules).** Score = failed attempts × 8 + threat level × 5
+ 15 extra points if the login is at night (before 6 AM or after 10 PM), max 100.
Low = below 35, Medium = 35 to 64, High = 65 and above.

**Step 3 – Make features.** The computer understands only numbers, so each event
becomes 5 numbers: failed_attempts, threat_level, login_hour, ip_number (IP turned
into a number) and ip_count (how many events came from that IP).

**Step 4 – Isolation Forest (finds unusual events, no labels needed).**
It builds many random decision trees. Strange events are "different" so they get
separated from the rest in very few splits. Fewer splits = more unusual = anomaly.
We expect about 5% anomalies (contamination = 0.05).

**Step 5 – Random Forest (classifies risk).** It builds 100 decision trees. Each
tree votes Low / Medium / High and the majority wins. The share of votes for the
winning class is the **confidence**. 80% of data is used for training and 20% for
testing accuracy.

**Step 6 – Combine.**
* Random Forest says High → **Malicious**
* Random Forest says Medium, or Isolation Forest says anomaly → **Suspicious**
* otherwise → **Normal**

Severity (Low / Medium / High / Critical) comes from the prediction and the score.

**Analogy:** Isolation Forest is a security guard who notices "that person looks
odd". Random Forest is a team of 100 guards who each vote "safe / watch / danger".

---
## PART 2 – 10 likely viva questions and answers

**1. What is your project about?**
SecureLog AI reads security logs, uses machine learning to detect suspicious login
behaviour and brute-force attacks, and shows the results on a dashboard with
charts, reports and e-mail alerts.

**2. Why did you use Python and Streamlit?**
Python has strong libraries for data and AI (pandas, scikit-learn). Streamlit
turns Python code into a web dashboard without needing HTML/JavaScript.

**3. What is a security log?**
A record kept by the operating system of events such as logins, failed logins,
logouts, account lockouts and privilege changes. Windows stores them in the
Security event log (e.g. Event ID 4624 = successful login, 4625 = failed login).

**4. What is Isolation Forest?**
An unsupervised anomaly-detection algorithm. It randomly splits data with trees;
unusual points get isolated quickly, so they get a high anomaly score.

**5. What is Random Forest?**
A supervised algorithm made of many decision trees. Each tree votes and the
majority vote is the answer. It is accurate and does not overfit easily.

**6. Supervised vs unsupervised learning?**
Supervised uses labelled data (we know the answer, e.g. Low/Medium/High) –
Random Forest. Unsupervised has no labels and finds patterns itself – Isolation Forest.

**7. Why use two models?**
Random Forest learns known risk patterns. Isolation Forest can catch new or rare
behaviour that rules have not seen. Together they are stronger.

**8. How do you get the Windows logs?**
With the `pywin32` library: `win32evtlog.OpenEventLog` opens the Security log and
`ReadEventLog` reads the events. It needs Administrator rights. If it fails, the
app uses sample data.

**9. How is the e-mail password kept safe?**
It is stored in a `.env` file (not in the code) and read with python-dotenv.
We use a Gmail App Password, and `.env` is never shared or uploaded.

**10. What are the limitations and future scope?**
Limitations: the sample data is fake and the Random Forest is trained on
rule-based labels, so accuracy is very high. Future scope: train on real labelled
attack data (e.g. CICIDS), hash admin passwords, add a database, real-time
auto-refresh, automatic IP blocking, and SMS/Telegram alerts.

**Bonus – Why is accuracy almost 100%?** Because the labels come from our own score
rule, which is built from the same features. The model easily learns the rule. This
is why the model is a demonstration, not a production security tool.

---
## PART 3 – Project report (simple English, easy to write by hand)

### Title
SecureLog AI – AI-Powered Security Log Analysis and Threat Detection System

### 1. Aim
To build a system that reads computer security logs, finds suspicious login
activity using machine learning, and shows the result on a simple dashboard.

### 2. Introduction
Every computer records events like logins and failed logins in security logs.
These logs are very large and a person cannot check them one by one. Attackers
often try many wrong passwords (brute-force attack) or log in at night. This
project uses Python and machine learning to check logs automatically, give each
event a threat score and risk level, and warn the administrator by e-mail.

### 3. Block diagram
```
 Windows Event Log ─┐
                    ├─► Data Loader ─► Feature ─► Isolation Forest ─┐
 CSV file upload  ──┘   (clean data)   Builder     (anomalies)      ├─► Threat Score,
                                                  Random Forest ────┘   Risk, AI Status
                                                  (Low/Med/High)              │
                                                                              ▼
                              Dashboard · AI Analysis · Charts · High Risk Users · Reports
                                                                              │
                                                                              ▼
                                                                    E-mail Alert (Gmail)
```

### 4. Tools used
* **Python 3** – programming language
* **Streamlit** – web dashboard
* **pandas, NumPy** – data handling
* **scikit-learn** – Isolation Forest and Random Forest
* **Plotly** – interactive charts
* **pywin32 (win32evtlog)** – reads Windows Security log
* **smtplib** – sends e-mail
* **python-dotenv** – keeps passwords in a .env file

### 5. Working
1. Admin logs in with username and password.
2. Data is taken from live Windows logs or an uploaded CSV file.
3. Data is cleaned and a threat score (0–100) is calculated.
4. Five features are made: failed attempts, threat level, login hour, IP number, IP count.
5. Isolation Forest finds unusual events; Random Forest predicts Low/Medium/High risk with confidence.
6. Results are combined into Normal, Suspicious or Malicious.
7. The dashboard shows metrics, tables, live threat monitoring and charts.
8. High-risk events can be e-mailed to the administrator, and a CSV report can be downloaded.

### 6. Results
Tested on 50,000 sample events:
* Low risk: 44,703 | Medium risk: 2,278 | High risk: 3,019
* Isolation Forest flagged about 5% of events as anomalies (2,559)
* Random Forest accuracy on test data: about 100% (labels come from the rule-based score)
* Attack usernames such as admin, root, guest and backup came out as the top high-risk users
* Overall security score: about 86 / 100, status "UNDER OBSERVATION"

### 7. Conclusion
SecureLog AI shows how machine learning can help to find brute-force attacks and
unusual logins quickly. The project is simple, works with live Windows logs or
CSV files, and gives alerts. In future it can be trained on real attack data and
extended with a database and automatic blocking of attackers.
