"""
email_alert.py - Sends an e-mail alert about high-risk events using Gmail.

The Gmail address and APP PASSWORD are read from the .env file,
so no password is written inside the code.
"""
import smtplib
from email.message import EmailMessage

from modules import config


def build_alert_text(high_df, max_rows=15):
    """Create the e-mail body from the high-risk events table."""
    lines = [
        "SecureLog AI - HIGH RISK SECURITY ALERT",
        "=" * 42,
        f"Total high-risk events : {len(high_df)}",
        f"Users involved         : {high_df['username'].nunique()}",
        "",
        f"Top {min(max_rows, len(high_df))} events (highest threat score first):",
        "",
    ]
    top = high_df.sort_values("threat_score", ascending=False).head(max_rows)
    for _, r in top.iterrows():
        lines.append(f"- User: {r['username']} | IP: {r['ip_address']} | "
                     f"Event: {r['event']} | Failed: {r['failed_attempts']} | "
                     f"Score: {r['threat_score']} | Time: {r['time']}")
    lines += ["", "Please check these accounts immediately.",
              "- SecureLog AI (automatic message)"]
    return "\n".join(lines)


def send_alert_email(high_df):
    """Send the alert. Returns (True/False, message to show the user)."""
    if high_df is None or len(high_df) == 0:
        return False, "No high-risk events found, so no alert was sent."

    sender, password, receiver = (config.EMAIL_SENDER,
                                  config.EMAIL_APP_PASSWORD,
                                  config.EMAIL_RECEIVER)
    if not (sender and password and receiver):
        return False, ("Email is not set up. Copy .env.example to .env and fill in "
                       "EMAIL_SENDER, EMAIL_APP_PASSWORD and EMAIL_RECEIVER.")

    msg = EmailMessage()
    msg["Subject"] = f"[SecureLog AI] {len(high_df)} HIGH RISK security events detected"
    msg["From"] = sender
    msg["To"] = receiver
    msg.set_content(build_alert_text(high_df))

    try:
        # Gmail SMTP over SSL, port 465
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=20) as server:
            server.login(sender, password.replace(" ", ""))
            server.send_message(msg)
        return True, f"Alert e-mail sent to {receiver}."
    except smtplib.SMTPAuthenticationError:
        return False, "Gmail login failed. Check the App Password in your .env file."
    except Exception as e:
        return False, f"Could not send e-mail: {e}"
