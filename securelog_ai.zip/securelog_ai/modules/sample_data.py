"""
sample_data.py - Creates FAKE security-log data for practice.

Used by:
  * dataset/generate_dataset.py  (makes the 50,000 row CSV file)
  * the app itself, when Windows logs cannot be read (fallback)
"""
import numpy as np
import pandas as pd

# 60 normal office users
NORMAL_USERS = [f"user{i:02d}" for i in range(1, 51)] + [
    "alice", "bob", "charlie", "david", "emma",
    "farah", "george", "hannah", "irfan", "julia",
]
# Names that attackers usually try (brute-force guessing)
ATTACK_USERS = ["admin", "root", "administrator", "guest", "test",
                "oracle", "support", "backup"]

NORMAL_EVENTS = ["Login Success", "Logoff", "Password Change", "File Access"]
SUSPICIOUS_EVENTS = ["Failed Login", "Login Success", "Privilege Escalation"]
ATTACK_EVENTS = ["Failed Login", "Account Lockout", "Privilege Escalation"]


def _hour_probabilities(kind):
    """Return how likely each hour (0-23) is, for normal or night-time attackers."""
    p = np.full(24, 0.3)
    if kind == "normal":
        p[8:19] = 8.0          # office hours 8 AM - 6 PM
        p[6:8] = 2.0
        p[19:22] = 2.0
    else:                       # attackers like the night
        p[0:6] = 6.0
        p[22:24] = 4.0
    return p / p.sum()


def generate_sample_data(n_rows=1000, seed=42, days=7):
    """Create a DataFrame of fake log rows.

    Columns: time, username, ip_address, event, failed_attempts,
             threat_level (1-10), login_hour
    """
    rng = np.random.default_rng(seed)  # seed => same data every time

    # 90% normal, 6% suspicious, 4% attack rows
    kind = rng.choice(["normal", "suspicious", "attack"], size=n_rows,
                      p=[0.90, 0.06, 0.04])
    is_n, is_s, is_a = kind == "normal", kind == "suspicious", kind == "attack"

    # ---- usernames ----
    username = rng.choice(NORMAL_USERS, size=n_rows)
    attack_name = rng.choice(ATTACK_USERS, size=n_rows)
    use_attack_name = is_a & (rng.random(n_rows) < 0.7)
    username = np.where(use_attack_name, attack_name, username)

    # ---- IP addresses (192.0.2.x / 203.0.113.x are reserved for examples) ----
    normal_ips = [f"192.168.{a}.{b}" for a in range(1, 4) for b in range(2, 60)]
    attack_ips = [f"203.0.113.{i}" for i in range(1, 21)]
    suspicious_ips = [f"198.51.100.{i}" for i in range(1, 41)]
    ip = rng.choice(normal_ips, size=n_rows)
    ip = np.where(is_s, rng.choice(suspicious_ips, size=n_rows), ip)
    ip = np.where(is_a, rng.choice(attack_ips, size=n_rows), ip)

    # ---- failed attempts and threat level ----
    failed = np.where(is_n, rng.choice([0, 0, 0, 1, 1, 2], size=n_rows), 0)
    failed = np.where(is_s, rng.integers(3, 6, size=n_rows), failed)
    failed = np.where(is_a, rng.integers(6, 16, size=n_rows), failed)

    threat = np.where(is_n, rng.integers(1, 4, size=n_rows), 0)
    threat = np.where(is_s, rng.integers(3, 7, size=n_rows), threat)
    threat = np.where(is_a, rng.integers(6, 11, size=n_rows), threat)

    # ---- login hour ----
    hour_normal = rng.choice(24, size=n_rows, p=_hour_probabilities("normal"))
    hour_attack = rng.choice(24, size=n_rows, p=_hour_probabilities("attack"))
    hour = np.where(is_n, hour_normal, hour_attack)
    hour = np.where(is_s, rng.integers(0, 24, size=n_rows), hour)

    # ---- event names ----
    event = np.where(is_n, rng.choice(NORMAL_EVENTS, size=n_rows,
                                      p=[0.45, 0.35, 0.05, 0.15]), "")
    event = np.where(is_s, rng.choice(SUSPICIOUS_EVENTS, size=n_rows,
                                      p=[0.5, 0.3, 0.2]), event)
    event = np.where(is_a, rng.choice(ATTACK_EVENTS, size=n_rows,
                                      p=[0.6, 0.25, 0.15]), event)

    # ---- time stamps: random day in the last `days` days + the login hour ----
    today = pd.Timestamp.now().normalize()
    day_offset = rng.integers(0, days, size=n_rows)
    minutes = rng.integers(0, 60, size=n_rows)
    seconds = rng.integers(0, 60, size=n_rows)
    time = (today - pd.to_timedelta(day_offset, unit="D")
            + pd.to_timedelta(hour, unit="h")
            + pd.to_timedelta(minutes, unit="m")
            + pd.to_timedelta(seconds, unit="s"))
    # Do not allow times in the future
    time = pd.Series(time).clip(upper=pd.Timestamp.now())

    df = pd.DataFrame({
        "time": time,
        "username": username,
        "ip_address": ip,
        "event": event,
        "failed_attempts": failed.astype(int),
        "threat_level": threat.astype(int),
        "login_hour": hour.astype(int),
    })
    return df.sort_values("time").reset_index(drop=True)
