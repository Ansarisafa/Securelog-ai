"""
ai_engine.py - The AI / machine-learning part of SecureLog AI.

Two models work together:
  1. Isolation Forest  (UNSUPERVISED)  -> finds unusual / rare events (anomalies)
  2. Random Forest     (SUPERVISED)    -> predicts risk level Low / Medium / High
                                          and gives a confidence (probability)

Features used: failed_attempts, threat_level, login_hour, ip_number, ip_count
"""
import ipaddress

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

FEATURE_COLUMNS = ["failed_attempts", "threat_level", "login_hour",
                   "ip_number", "ip_count"]
MAX_TRAIN_ROWS = 20_000   # use at most this many rows for training (keeps it fast)


# --------------------------------------------------------------------------
# Step 1: rule-based threat score (0-100) and risk level
# --------------------------------------------------------------------------
def add_rule_based_score(df):
    """Threat score = failed attempts + event danger + odd-hour bonus."""
    off_hours = ((df["login_hour"] < 6) | (df["login_hour"] >= 22)).astype(int)
    score = df["failed_attempts"] * 8 + df["threat_level"] * 5 + off_hours * 15
    df["threat_score"] = score.clip(0, 100).round(1)
    # Low: below 35 | Medium: 35-64 | High: 65 and above
    df["risk_level"] = np.select([df["threat_score"] >= 65, df["threat_score"] >= 35],
                                 ["High", "Medium"], default="Low")
    # A short plain-English description of the behaviour
    df["behavior"] = np.select(
        [df["failed_attempts"] >= 8, df["failed_attempts"] >= 5,
         df["failed_attempts"] >= 3, off_hours == 1, df["threat_level"] >= 7],
        ["Brute-force attack pattern", "Repeated failed logins",
         "Multiple failed logins", "Login at unusual hour", "Dangerous event type"],
        default="Normal activity")
    return df


# --------------------------------------------------------------------------
# Step 2: turn each row into numbers the models can use (features)
# --------------------------------------------------------------------------
def ip_to_number(ip):
    """Convert an IP such as 192.168.1.5 into a number."""
    try:
        return int(ipaddress.ip_address(str(ip).strip())) % (2 ** 32)
    except ValueError:
        return 0


def build_features(df):
    ip_map = {ip: ip_to_number(ip) for ip in df["ip_address"].unique()}
    feats = pd.DataFrame(index=df.index)
    feats["failed_attempts"] = df["failed_attempts"]
    feats["threat_level"] = df["threat_level"]
    feats["login_hour"] = df["login_hour"]
    feats["ip_number"] = df["ip_address"].map(ip_map)
    # how many events came from the same IP (busy IPs can mean an attack)
    feats["ip_count"] = df.groupby("ip_address")["ip_address"].transform("count")
    return feats[FEATURE_COLUMNS]


def _sample_rows(array, n, seed=42):
    """Take n random rows (used so training stays fast on big files)."""
    if len(array) <= n:
        return np.arange(len(array))
    return np.random.default_rng(seed).choice(len(array), n, replace=False)


# --------------------------------------------------------------------------
# Step 3: the main function - runs both models and adds the AI columns
# --------------------------------------------------------------------------
def analyze(df):
    """Return (result_dataframe, info_dictionary)."""
    if df is None or len(df) < 2:
        raise ValueError("At least 2 rows are needed for AI analysis.")

    df = df.copy().sort_values("time").reset_index(drop=True)
    df = add_rule_based_score(df)
    X = build_features(df)

    # ---------- Isolation Forest : anomaly detection ----------
    scaler = StandardScaler().fit(X)
    X_scaled = scaler.transform(X)
    iso = IsolationForest(n_estimators=100, contamination=0.05,
                          random_state=42, n_jobs=-1)
    iso.fit(X_scaled[_sample_rows(X_scaled, MAX_TRAIN_ROWS)])
    is_anomaly = iso.predict(X_scaled) == -1               # -1 means "anomaly"
    raw = -iso.decision_function(X_scaled)                  # bigger = more unusual
    anomaly_score = (raw - raw.min()) / (raw.max() - raw.min() + 1e-9)

    # ---------- Random Forest : risk classification ----------
    y = df["risk_level"]
    accuracy = None
    X_train, y_train = X, y
    if len(df) >= 30:
        try:
            stratify = y if (y.nunique() > 1 and y.value_counts().min() >= 2) else None
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=stratify)
        except ValueError:
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42)
    idx = _sample_rows(X_train, MAX_TRAIN_ROWS)
    rf = RandomForestClassifier(n_estimators=100, max_depth=10,
                                random_state=42, n_jobs=-1)
    rf.fit(X_train.iloc[idx], y_train.iloc[idx])
    if len(df) >= 30:
        accuracy = float(rf.score(X_test, y_test))

    rf_pred = rf.predict(X)
    confidence = rf.predict_proba(X).max(axis=1) * 100

    # ---------- Combine both models ----------
    # High -> Malicious | Medium or anomaly -> Suspicious | else Normal
    pred = np.select([rf_pred == "High", (rf_pred == "Medium") | is_anomaly],
                     ["Malicious", "Suspicious"], default="Normal")
    severity = np.select(
        [(pred == "Malicious") & (df["threat_score"] >= 85), pred == "Malicious",
         pred == "Suspicious"], ["Critical", "High", "Medium"], default="Low")
    status = np.select([pred == "Malicious", pred == "Suspicious"],
                       ["Threat Detected", "Suspicious"], default="Safe")

    df["ai_prediction"] = pred
    df["confidence"] = confidence.round(1)
    df["severity"] = severity
    df["ai_status"] = status
    df["is_anomaly"] = is_anomaly
    df["anomaly_score"] = anomaly_score.round(3)

    # ---------- AI reason (simple English explanation) ----------
    fa, hr, tl = df["failed_attempts"], df["login_hour"], df["threat_level"]
    reason = (
        ("Failed attempts: " + fa.astype(str) + ". ").where(fa >= 3, "")
        + ("Login at odd hour (" + hr.astype(str) + ":00). ").where((hr < 6) | (hr >= 22), "")
        + ("High-danger event (level " + tl.astype(str) + "). ").where(tl >= 6, "")
        + pd.Series(np.where(is_anomaly, "Unusual pattern found by Isolation Forest. ", ""),
                    index=df.index)
    ).str.strip()
    reason = reason.where(reason != "", "Combined risk factors raised the score.")
    df["ai_reason"] = reason.where(df["ai_prediction"] != "Normal", "No suspicious signs.")

    info = {
        "rows": len(df),
        "accuracy": accuracy,
        "anomalies": int(is_anomaly.sum()),
        "feature_importance": {name: round(float(v), 3) for name, v in
                               zip(FEATURE_COLUMNS, rf.feature_importances_)},
    }
    return df, info


# --------------------------------------------------------------------------
# Helper summaries used by the pages
# --------------------------------------------------------------------------
def top_risk_users(df, n=10):
    """Top n users with the highest average threat score."""
    g = df.groupby("username").agg(
        events=("username", "size"),
        malicious_events=("ai_prediction", lambda s: int((s == "Malicious").sum())),
        avg_failed_attempts=("failed_attempts", "mean"),
        avg_threat_score=("threat_score", "mean"),
        max_threat_score=("threat_score", "max"),
    ).reset_index()
    g["avg_failed_attempts"] = g["avg_failed_attempts"].round(2)
    g["avg_threat_score"] = g["avg_threat_score"].round(1)
    return g.sort_values("avg_threat_score", ascending=False).head(n).reset_index(drop=True)


def security_score(df):
    """Overall health 0-100 (100 = very safe)."""
    mal = (df["ai_prediction"] == "Malicious").mean() * 100
    sus = (df["ai_prediction"] == "Suspicious").mean() * 100
    return round(float(np.clip(100 - mal * 2 - sus * 0.5, 0, 100)), 1)


def live_threat_status(df, window=200):
    """Numbers for the 'Live Threat Monitoring' box (uses the newest events)."""
    recent = df.tail(window)
    high_pct = (recent["risk_level"] == "High").mean() * 100
    # threat % = average score + extra weight for the share of high-risk events
    threat_pct = round(float(min(100, recent["threat_score"].mean() + 2 * high_pct)), 1)
    if threat_pct >= 40:
        level, status = "High", "UNDER ATTACK"
    elif threat_pct >= 20:
        level, status = "Medium", "UNDER OBSERVATION"
    else:
        level, status = "Low", "SECURE"
    return {
        "level": level, "status": status, "threat_pct": threat_pct,
        "failed_logins": int((recent["failed_attempts"] > 0).sum()),
        # "blocked" users = users with 5+ failed attempts (would be auto-blocked)
        "blocked_users": int(recent.loc[recent["failed_attempts"] >= 5, "username"].nunique()),
    }
