"""
styles.py - Extra CSS that makes the app look like a dark security dashboard.
"""

CSS = """
<style>
/* header cards on the dashboard */
.info-card {background:#161b22; border:1px solid #30363d; border-radius:12px;
            padding:14px 18px; margin-bottom:10px;}
.info-card .label {color:#8b949e; font-size:13px;}
.info-card .value {color:#e6edf3; font-size:20px; font-weight:700;}

/* green System Online box in the sidebar */
.online-box {background:#0f2e1a; border:1px solid #21c354; color:#21c354;
             border-radius:10px; padding:10px; text-align:center;
             font-weight:700; margin-top:10px;}

/* live threat monitoring box */
.monitor-box {background:#161b22; border:1px solid #30363d; border-radius:12px;
              padding:16px 20px; margin:10px 0 20px 0;}
.monitor-grid {display:flex; flex-wrap:wrap; gap:24px; margin-top:8px;}
.monitor-item .label {color:#8b949e; font-size:13px;}
.monitor-item .value {font-size:22px; font-weight:800;}

/* metric cards */
div[data-testid="stMetric"] {background:#161b22; border:1px solid #30363d;
                             border-radius:12px; padding:12px 16px;}
.login-title {text-align:center; font-size:34px; font-weight:800;}
.login-sub {text-align:center; color:#8b949e; margin-bottom:20px;}
</style>
"""
