"""
windows_logs.py - Reads the Windows SECURITY event log with pywin32.

Notes for students:
  * Works only on Windows and only if pywin32 is installed.
  * Reading the Security log needs ADMINISTRATOR rights
    (run the terminal as Administrator).
  * If anything goes wrong, we raise WindowsLogError and the app
    automatically falls back to sample data.
"""
import platform
from datetime import datetime

import pandas as pd


class WindowsLogError(Exception):
    """Raised when the Windows log cannot be read."""


# Important Windows Security Event IDs we care about:
#   id: (event name, threat level 1-10, username position, ip position)
# The positions are the index numbers inside the event's "StringInserts" list.
EVENT_INFO = {
    4624: ("Login Success",          1, 5, 18),
    4625: ("Failed Login",           6, 5, 19),
    4634: ("Logoff",                 1, 1, None),
    4647: ("User Initiated Logoff",  1, 1, None),
    4648: ("Login With Explicit Credentials", 4, 5, 12),
    4672: ("Special Privileges Assigned",     4, 1, None),
    4720: ("User Account Created",   5, 0, None),
    4724: ("Password Reset Attempt", 5, 0, None),
    4740: ("Account Locked Out",     9, 0, None),
}


def _safe_get(items, index):
    """Return items[index] or '' if it does not exist (avoids crashes)."""
    try:
        if index is not None and items and index < len(items):
            return str(items[index]).strip()
    except Exception:
        pass
    return ""


def read_windows_security_log(max_events=500, max_scan=5000):
    """Read the newest security events and return a clean DataFrame.

    max_events : how many useful events to keep
    max_scan   : how many log records to look at (many are not useful)
    """
    if platform.system() != "Windows":
        raise WindowsLogError("This computer is not running Windows.")

    try:
        import win32evtlog  # installed with pywin32
    except ImportError:
        raise WindowsLogError("pywin32 is not installed (pip install pywin32).")

    try:
        handle = win32evtlog.OpenEventLog(None, "Security")  # needs admin rights
    except Exception as e:
        raise WindowsLogError(f"Access denied or log unavailable: {e}")

    rows, scanned = [], 0
    flags = (win32evtlog.EVENTLOG_BACKWARDS_READ      # newest first
             | win32evtlog.EVENTLOG_SEQUENTIAL_READ)
    try:
        while len(rows) < max_events and scanned < max_scan:
            records = win32evtlog.ReadEventLog(handle, flags, 0)
            if not records:
                break
            for rec in records:
                scanned += 1
                event_id = rec.EventID & 0xFFFF       # real ID is the lower 16 bits
                if event_id not in EVENT_INFO:
                    continue
                name, threat, user_pos, ip_pos = EVENT_INFO[event_id]
                inserts = rec.StringInserts or []
                username = _safe_get(inserts, user_pos) or "UNKNOWN"
                if username.endswith("$"):            # skip computer accounts
                    continue
                ip = _safe_get(inserts, ip_pos)
                if ip in ("", "-", "::1"):
                    ip = "127.0.0.1"
                t = rec.TimeGenerated
                t = datetime(t.year, t.month, t.day, t.hour, t.minute, t.second)
                rows.append({"time": t, "username": username, "ip_address": ip,
                             "event": name, "event_id": event_id,
                             "threat_level": threat})
                if len(rows) >= max_events:
                    break
    except Exception as e:
        raise WindowsLogError(f"Error while reading the log: {e}")
    finally:
        win32evtlog.CloseEventLog(handle)

    if not rows:
        raise WindowsLogError("No usable security events were found.")

    df = pd.DataFrame(rows).sort_values("time").reset_index(drop=True)

    # failed_attempts = how many failed logins this user has had so far
    df["is_failed"] = (df["event_id"] == 4625).astype(int)
    df["failed_attempts"] = df.groupby("username")["is_failed"].cumsum()
    df["login_hour"] = df["time"].dt.hour
    return df.drop(columns=["is_failed"])
