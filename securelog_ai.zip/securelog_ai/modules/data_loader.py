"""
data_loader.py - Loads and cleans log data from 3 places:
   1) Live Windows Event Logs   2) an uploaded CSV   3) sample data
Every source is converted to the SAME column format so the rest of the
app does not care where the data came from.
"""
import pandas as pd

from modules.config import SAMPLE_CSV
from modules.sample_data import generate_sample_data
from modules.windows_logs import WindowsLogError, read_windows_security_log

# A CSV must contain at least these columns
REQUIRED_COLUMNS = ["username", "ip_address", "failed_attempts", "threat_level"]

# Other common column names that we accept and rename
ALIASES = {
    "user": "username", "user_name": "username", "account": "username",
    "ip": "ip_address", "ipaddress": "ip_address", "source_ip": "ip_address",
    "failed_logins": "failed_attempts", "failed": "failed_attempts",
    "timestamp": "time", "time_stamp": "time", "datetime": "time", "date": "time",
    "hour": "login_hour",
}


def prepare_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Clean any log table so that it has all the columns the app needs."""
    df = df.copy()

    # 1) tidy the column names: lowercase, spaces -> underscore, rename aliases
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    df = df.rename(columns={k: v for k, v in ALIASES.items() if k in df.columns})

    # 2) check that the required columns exist
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError("Your CSV is missing these columns: " + ", ".join(missing)
                         + ". Required columns: " + ", ".join(REQUIRED_COLUMNS))
    if df.empty:
        raise ValueError("The file has no rows.")

    # 3) make number columns numeric (bad values become 0)
    df["failed_attempts"] = pd.to_numeric(df["failed_attempts"], errors="coerce").fillna(0).clip(lower=0)
    df["threat_level"] = pd.to_numeric(df["threat_level"], errors="coerce").fillna(0).clip(0, 10)
    df["failed_attempts"] = df["failed_attempts"].astype(int)
    df["threat_level"] = df["threat_level"].astype(int)

    # 4) text columns
    df["username"] = df["username"].fillna("UNKNOWN").astype(str)
    df["ip_address"] = df["ip_address"].fillna("0.0.0.0").astype(str)
    if "event" not in df.columns:
        df["event"] = "Login Event"
    df["event"] = df["event"].fillna("Login Event").astype(str)

    # 5) time and login hour
    now = pd.Timestamp.now()
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], errors="coerce")
    elif "login_hour" in df.columns:
        hours = pd.to_numeric(df["login_hour"], errors="coerce").fillna(0).clip(0, 23)
        df["time"] = now.normalize() + pd.to_timedelta(hours, unit="h")
    else:
        # no time information at all: spread rows one minute apart ending now
        df["time"] = now - pd.to_timedelta(range(len(df) - 1, -1, -1), unit="min")
    df["time"] = df["time"].fillna(now)

    if "login_hour" in df.columns:
        df["login_hour"] = pd.to_numeric(df["login_hour"], errors="coerce")
        df["login_hour"] = df["login_hour"].fillna(df["time"].dt.hour).clip(0, 23).astype(int)
    else:
        df["login_hour"] = df["time"].dt.hour

    keep = ["time", "username", "ip_address", "event",
            "failed_attempts", "threat_level", "login_hour"]
    return df[keep].sort_values("time").reset_index(drop=True)


def load_csv(file) -> pd.DataFrame:
    """Read an uploaded CSV file (or a file path) and clean it."""
    return prepare_dataframe(pd.read_csv(file))


def load_sample_dataset() -> pd.DataFrame:
    """Use dataset/sample_logs.csv if it exists, otherwise make 5000 rows."""
    if SAMPLE_CSV.exists():
        return load_csv(SAMPLE_CSV)
    return prepare_dataframe(generate_sample_data(5000))


def load_live_logs():
    """Try the real Windows logs; on any problem use sample data.

    Returns (DataFrame, message_for_the_user, is_live_data)
    """
    try:
        df = read_windows_security_log()
        return prepare_dataframe(df), "Live Windows Security log loaded.", True
    except WindowsLogError as e:
        fallback = prepare_dataframe(generate_sample_data(500))
        return fallback, f"Could not read live logs ({e}) Showing SAMPLE data instead.", False
