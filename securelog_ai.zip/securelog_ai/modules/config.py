"""
config.py - Reads settings from the .env file.
Secrets (passwords) are kept in .env, NOT inside the code.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

# BASE_DIR = the main project folder (the one that contains app.py)
BASE_DIR = Path(__file__).resolve().parent.parent

# Load the values written in the .env file (if the file exists)
load_dotenv(BASE_DIR / ".env")

# Admin login (default: admin / admin123 if .env is missing)
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")

# Gmail settings (used only by the Email Alert System)
EMAIL_SENDER = os.getenv("EMAIL_SENDER", "")
EMAIL_APP_PASSWORD = os.getenv("EMAIL_APP_PASSWORD", "")
EMAIL_RECEIVER = os.getenv("EMAIL_RECEIVER", "")

# Path of the ready-made sample dataset
SAMPLE_CSV = BASE_DIR / "dataset" / "sample_logs.csv"
