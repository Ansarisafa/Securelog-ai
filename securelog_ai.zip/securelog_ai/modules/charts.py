"""
charts.py - All Plotly charts. Each function returns a figure; app.py shows it.
"""
import pandas as pd
import plotly.express as px

# Same colours everywhere so the dashboard looks consistent
COLORS = {
    "Low": "#21c354", "Medium": "#ffa500", "High": "#ff4b4b",
    "Normal": "#21c354", "Suspicious": "#ffa500", "Malicious": "#ff4b4b",
}


def _dark(fig, height=340):
    """Apply the dark look to a figure."""
    fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", height=height,
                      margin=dict(l=10, r=10, t=40, b=10))
    return fig


def prediction_donut(df):
    """AI Prediction Distribution (donut chart)."""
    counts = df["ai_prediction"].value_counts().reset_index()
    counts.columns = ["AI Prediction", "Events"]
    fig = px.pie(counts, names="AI Prediction", values="Events", hole=0.55,
                 color="AI Prediction", color_discrete_map=COLORS,
                 title="AI Prediction Distribution")
    return _dark(fig)


def threat_score_bar(df):
    """Average threat score for each AI prediction group (bar chart)."""
    avg = df.groupby("ai_prediction")["threat_score"].mean().round(1).reset_index()
    avg.columns = ["AI Prediction", "Average Threat Score"]
    fig = px.bar(avg, x="AI Prediction", y="Average Threat Score",
                 color="AI Prediction", color_discrete_map=COLORS,
                 title="Threat Score by AI Prediction", text="Average Threat Score")
    return _dark(fig)


def top_users_bar(top_df):
    """Top high-risk users (bar chart)."""
    fig = px.bar(top_df, x="username", y="avg_threat_score",
                 title="Top 10 High Risk Users (average threat score)",
                 color="avg_threat_score", color_continuous_scale="Reds")
    return _dark(fig)


def feature_importance_bar(importance):
    """Which features the Random Forest used the most."""
    data = pd.DataFrame({"Feature": list(importance.keys()),
                         "Importance": list(importance.values())})
    fig = px.bar(data.sort_values("Importance"), x="Importance", y="Feature",
                 orientation="h", title="Feature Importance (Random Forest)")
    return _dark(fig, height=280)


def hourly_activity(df):
    """Login Activity by Hour (0-23)."""
    counts = df["login_hour"].value_counts().reindex(range(24), fill_value=0)
    data = pd.DataFrame({"Hour": counts.index, "Events": counts.values})
    fig = px.bar(data, x="Hour", y="Events", title="Login Activity by Hour")
    fig.update_xaxes(dtick=1)
    return _dark(fig)


def risk_comparison(df):
    """Risk Level Comparison (Low / Medium / High)."""
    counts = df["risk_level"].value_counts().reindex(["Low", "Medium", "High"], fill_value=0)
    data = pd.DataFrame({"Risk Level": counts.index, "Events": counts.values})
    fig = px.bar(data, x="Risk Level", y="Events", color="Risk Level",
                 color_discrete_map=COLORS, title="Risk Level Comparison", text="Events")
    return _dark(fig)


def events_over_time(df):
    """Events over time (line chart, one line per risk level)."""
    span_days = (df["time"].max() - df["time"].min()).days
    if span_days <= 2:
        freq = "60min"        # hourly
    elif span_days <= 14:
        freq = "360min"       # every 6 hours
    else:
        freq = "1D"           # daily
    data = (df.groupby([pd.Grouper(key="time", freq=freq), "risk_level"])
              .size().reset_index(name="Events"))
    fig = px.line(data, x="time", y="Events", color="risk_level", markers=True,
                  color_discrete_map=COLORS, title="Events Over Time",
                  labels={"time": "Time", "risk_level": "Risk Level"})
    return _dark(fig, height=380)
