"""
auth.py - Simple admin login check.
"""
import hmac

from modules.config import ADMIN_PASSWORD, ADMIN_USERNAME


def check_login(username: str, password: str) -> bool:
    """Return True only if username AND password are correct.

    hmac.compare_digest compares text in a safe way (it takes the same time
    whether the text is right or wrong, so attackers cannot guess from timing).
    """
    user_ok = hmac.compare_digest(username.strip(), ADMIN_USERNAME)
    pass_ok = hmac.compare_digest(password, ADMIN_PASSWORD)
    return user_ok and pass_ok
